<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="forest" tilewidth="16" tileheight="16" tilecount="18" columns="6">
 <image source="tileset1.png" width="96" height="48"/>
</tileset>
